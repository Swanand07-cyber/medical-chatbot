package com.medicalchatbot.medical_chatbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalChatbotApplicationTests {

	@Test
	void contextLoads() {
	}

}
