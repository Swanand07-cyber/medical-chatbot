package com.medicalchatbot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.medicalchatbot.service.ChatService;

@Controller
public class ChatController {

    @Autowired
    private ChatService chatService;

    @GetMapping("/")
    public String home() {
        return "chatbot";
    }

    @PostMapping("/chat")
    public String chat(
            @RequestParam String symptom,
            Model model) {

        String response = chatService.getResponse(symptom);

        model.addAttribute("response", response);

        return "chatbot";
    }
}