package com.medicalchatbot.service;

import com.medicalchatbot.model.Disease;
import com.medicalchatbot.repository.DiseaseRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    private final DiseaseRepository repository;

    public DataLoader(DiseaseRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) {

        if(repository.count() > 0)
            return;

        Disease d1 = new Disease();
        d1.setDiseaseName("Malaria");
        d1.setSymptoms("chills,vomiting,high fever,sweating,headache");
        d1.setPrecautions("consult doctor,drink water,take rest");
        d1.setRiskFactors("mosquito bites");
        d1.setMedicines("Paracetamol");
        repository.save(d1);

        Disease d2 = new Disease();
        d2.setDiseaseName("Typhoid");
        d2.setSymptoms("high fever,headache,nausea,vomiting");
        d2.setPrecautions("consult doctor,avoid outside food");
        d2.setRiskFactors("contaminated water");
        d2.setMedicines("Antibiotics");
        repository.save(d2);

        Disease d3 = new Disease();
        d3.setDiseaseName("Dengue");
        d3.setSymptoms("fever,headache,joint pain,skin rash");
        d3.setPrecautions("drink fluids,take rest");
        d3.setRiskFactors("mosquito bites");
        d3.setMedicines("Paracetamol");
        repository.save(d3);

        System.out.println("Disease data inserted successfully!");
    }
}