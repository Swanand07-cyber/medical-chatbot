package com.medicalchatbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalChatbotApplication {

    public static void main(String[] args) {
        SpringApplication.run(MedicalChatbotApplication.class, args);
    }
}