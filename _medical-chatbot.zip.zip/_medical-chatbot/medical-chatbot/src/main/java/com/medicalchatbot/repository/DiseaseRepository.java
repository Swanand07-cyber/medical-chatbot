package com.medicalchatbot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.medicalchatbot.model.Disease;

public interface DiseaseRepository extends JpaRepository<Disease, Long> {

}