package com.medicalchatbot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicalchatbot.model.Disease;

@Service
public class ChatService {

    @Autowired
    private DataLoader dataLoader;

    public String getResponse(String symptom) {

        List<Disease> diseases = dataLoader.getDiseases();

        for (Disease disease : diseases) {

            if (disease.getSymptoms() != null &&
                    disease.getSymptoms().toLowerCase()
                            .contains(symptom.toLowerCase())) {

                return "<h2>Disease : " + disease.getDiseaseName() + "</h2>"

                        + "<b>Symptoms :</b><br>"
                        + disease.getSymptoms()

                        + "<br><br><b>Precautions :</b><br>"
                        + disease.getPrecautions()

                        + "<br><br><b>Risk Factors :</b><br>"
                        + disease.getRiskFactors()

                        + "<br><br><b>Medicines :</b><br>"
                        + disease.getMedicines();
            }
        }

        return "No disease found.";
    }
}